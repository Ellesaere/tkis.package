# # Bash Commands

# git push origin main
# git commit -m "initial commit"
# git branch -M main
# git commit -m "First commit"
# git status

# git remote remove origin
# git remote add origin https://github.com/Ellesaere/tkis_package.git

# C:\Two Drive\OneDrive\Coding\R_scripts>R CMD build tkis_package

# c:
# cd C:\Two Drive\OneDrive\Coding\R_scripts\tkis_package

# # cd /c/Two\ Drive/OneDrive/Coding/R_scripts/tkis_package
# # First time # DONE
# # https://kbroman.org/github_tutorial/pages/first_time.html 
# # Key ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCscbyeT5d4xWMApfVTxyHvZTkFMTqtXSbqshN3aazCUMyXK6bfQeaHHCJEUqn5do4D/SR0oFTsX5PrQoK2xmSfAMaeIGN4CW7cWWekGkYYrW654u0J3Z3WvV7t4l0UebjzYMsB3woMJ3tuVgombl57B6Z288VNhHcFTxnYXOFvd2zJSM6VlmeVXRFudKbpA0eeu35s7pjhDlGCWZt7kQ/iBCtr7wa+JmfD8rDw2FT/IYik+U9KQmbFSNzfbID1ZN0qxK9zJsLfbOYxwFvbw2Qsf5Eq3Fc4q0TRAKyPxf7hhSPMLaD4/xarKleUjQtQYu8x3x3bwyBKfkPt4xNgeUD/Y6qHezy2FBAE5peqxSqsLpif4dJT8eVnJ+qHQUGMGh/X8DrlVNUgyyCRsUYDJCdToh66zNwVPFGfVaewzGkkgwSGC250BmOU463F6M2+N3j0g75HUCTtpYYTWOZdY2SRAzZozDcK0//Qid7ZP1mtqDfrIUWrO+9snUZ2N4sCMDU= tomkisters@gmail.com
# # https://kbroman.org/pkg_primer/pages/github.html
# # https://stackoverflow.com/questions/4181861/message-src-refspec-master-does-not-match-any-when-pushing-commits-in-git
# # https://github.com/RehanSaeed/Bash-Cheat-Sheet
# # https://stackoverflow.com/questions/59332234/r-install-github-error-failed-to-install-unknown-package
# build()